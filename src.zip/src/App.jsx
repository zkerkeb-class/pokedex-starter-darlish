import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Pokemons from './components/Pokemons';
import ShinyPokemons from './components/ShinyPokemons';
import { AuthProvider } from './components/auth/AuthContext';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Profile from './components/auth/Profile';
import './App.css';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? "dark-mode" : "light-mode"}>
      <AuthProvider>
        <Router>
          <div style={{ textAlign: "center", margin: "20px" }}>
            <button 
              onClick={() => setDarkMode(!darkMode)}
              style={{
                padding: "10px 20px",
                borderRadius: "10px",
                border: "none",
                cursor: "pointer",
                backgroundColor: darkMode ? "#fff" : "#333",
                color: darkMode ? "#333" : "#fff",
                fontWeight: "bold",
                marginBottom: "20px",
                boxShadow: "0 2px 8px rgba(0,0,0,0.2)"
              }}
            >
              {darkMode ? "☀️ Mode Clair" : "🌙 Mode Sombre"}
            </button>
          </div>

          <Routes>
            <Route path="/" element={<Pokemons />} />
            <Route path="/shinypokemons" element={<ShinyPokemons />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </Router>
      </AuthProvider>
    </div>
  );
}

export default App;
