

const Header = ({prenom, age}) => {

    return (
        <div>
            <h1>{prenom}</h1>
            <p>{age}</p>
        </div>
    )
}

export default Header